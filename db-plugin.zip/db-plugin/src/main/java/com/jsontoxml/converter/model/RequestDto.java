package com.jsontoxml.converter.model;

import java.util.List;

public class RequestDto {



        private List<LiquibaseRequestDTO> liquibaseRequestDTOList;

        public List<LiquibaseRequestDTO> getLiquibaseRequestDTOList() {
            return liquibaseRequestDTOList;
        }
    }


