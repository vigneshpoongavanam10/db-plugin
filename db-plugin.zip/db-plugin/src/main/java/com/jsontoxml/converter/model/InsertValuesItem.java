package com.jsontoxml.converter.model;

public class InsertValuesItem {
    private String column;
    private String value;
    private String valueNumeric;

    public String getValueNumeric() {
        return valueNumeric;
    }

    public String getColumn() {
        return column;
    }

    public String getValue() {
        return value;
    }
}
