package com.jsontoxml.converter.user;

public enum Role {
    USER,
    ADMIN
}
