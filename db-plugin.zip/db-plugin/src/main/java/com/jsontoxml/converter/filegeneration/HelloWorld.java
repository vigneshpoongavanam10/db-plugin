package com.jsontoxml.converter.filegeneration;

import java.lang.String;
import java.lang.System;

public class HelloWorld {
  public static void main(String[] args) {
    System.out.println("Hello, JavaPoet!");
  }
}
